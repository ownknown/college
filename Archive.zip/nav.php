<nav>
    <a href="show-students.php">Students</a>
    <a href="show-courses.php">Courses</a>
    <a href="show-subjects.php">Subjects</a>
</nav>
