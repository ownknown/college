# college
college administrations system recording information about students, courses, subjects, lecturers
